/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mycaculator;

/**
 *
 * @author testy
 */
public class MyCaculator {

    public static void main(String[] args) {
         mycar obj = new mycar();
        obj.setVisible(true);
    }
}
